def secret_function():
    print("I must remember my username is shani and I have read the course guidelines.")
