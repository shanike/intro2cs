import math

import wave_helper
import os.path


def main():
    choice = None
    while choice != EXIT:
        choice = show_entrance_menu()


MAX_NUM = 32_767
MIN_NUM = -32_768
SAMPLE_RATE = 2_000
SIXTEEN_HUNDREDTHS_SECOND = 125
NOTE_TO_FREQUENCY = {
    "A": 440,
    "B": 494,
    "C": 523,
    "D": 587,
    "E": 659,
    "F": 698,
    "G": 784,
    "Q": 0,
}

ENTRANCE_MENU = """1.wav file change
2.compose a wav file
3.exit program
"""
WAV_MANIPULATION = "1"
COMPOSE_WAV = "2"
EXIT = "3"

MANIPULATION_MENU = """1.reverse file change
2.negative
3.speed up audio
4.slow down audio
5.increase volume
6.decrease volume
7.low pass filter
8.continue to finish menu
"""


def show_entrance_menu():
    choice = input(ENTRANCE_MENU)

    if choice == WAV_MANIPULATION:
        handle_wav_manipulation_selection()
    elif choice == COMPOSE_WAV:
        handle_compose_wav()
    return choice


def handle_wav_manipulation_selection():
    wav_file = input("Enter wav file to change: ")
    load_res = wave_helper.load_wave(wav_file)
    if load_res == -1:
        handle_wav_manipulation_selection()  # if couldn't load file -> ask user again
        return
    sample_rate, audio_data = load_res
    user_manipulation_selection = True
    while user_manipulation_selection != "8":  # 8 is to finish menu -- done showing manipulation menu
        user_manipulation_selection = show_manipulation_menu(audio_data)
    show_finish_menu(audio_data, sample_rate)


def handle_compose_wav():
    compose_instructions_filename = input("Enter compose instructions file name: ")
    while not os.path.exists(compose_instructions_filename):
        print("no such file")
        compose_instructions_filename = input("Enter compose instructions file name: ")

    audio_data = compose_wav(compose_instructions_filename)
    user_manipulation_selection = True
    while user_manipulation_selection != "8":  # 8 is to finish menu -- done showing manipulation menu
        user_manipulation_selection = show_manipulation_menu(audio_data)
    show_finish_menu(audio_data, SAMPLE_RATE)  # selected 8


def compose_wav(instructions_filename):
    instructions_f = open(instructions_filename, 'r')
    instructions = instructions_f.read().split()
    instructions_f.close()
    audio_data = []
    for wave_i in range(0, len(instructions), 2):
        frequency = NOTE_TO_FREQUENCY[instructions[wave_i]]
        sixteen_hundredths_second_count = int(instructions[wave_i + 1])
        for i in range(sixteen_hundredths_second_count * SIXTEEN_HUNDREDTHS_SECOND):
            samples_per_cycle = SAMPLE_RATE / frequency
            sample = int(MAX_NUM * math.sin(math.pi * 2 * (i / samples_per_cycle)))
            audio_data.append([sample, sample])
    return audio_data


def reverse_sound(sound_list: [[int, int]]):
    """
    gets the .wav sound list and reverses it's order
    :param sound_list: List of lists of two elements from int type
    """
    sound_list.reverse()


def speed_up_sound(sound_list):
    """
    speed audio sound, by keeping only even indexes
    :return:  new sound list
    """
    del sound_list[1::2]


def increase_volume(sound_list):
    """
    increase volume of sound by 1.2.
    if higher than MAX_NUM or lower than MIN_NUM will take the MAX_NUM or MIN_NUM respectively
    :param sound_list: List of lists of two elements from int type
    """
    for i in range(len(sound_list)):
        # for j in range(2):  # couldn't decide which we like better :)
        sound_list[i][0] = valid_int(int(sound_list[i][0] * 1.2))
        sound_list[i][1] = valid_int(int(sound_list[i][1] * 1.2))


def decrease_volume(sound_list):
    """
    decrease volume of sound by 1.2.
    :param sound_list: List of lists of two elements from int type
    """
    for i in range(len(sound_list)):
        for j in range(2):
            sound_list[i][j] = valid_int(int(sound_list[i][j] / 1.2))


def negative_sound(sound_list):
    """
    negative the audio
    :param sound_list: List of lists of two elements from int type
    """
    for i in range(len(sound_list)):
        sound_list[i][0] = valid_int(-1 * sound_list[i][0])
        sound_list[i][1] = valid_int(-1 * sound_list[i][1])


def valid_int(n):
    """
    if <n> is not between MAX and MIN number values:
    returns MAX or MIN respectively.
    otherwise returns <n>
    """
    if n > MAX_NUM:
        return MAX_NUM
    if n < MIN_NUM:
        return MIN_NUM
    return n


def slow_down_audio(sound_list: [int]):
    """
    Slows down the audio in
    :param sound_list: List of lists of two elements from int type
    """
    for i in range(len(sound_list) - 1, 0, -1):
        sound_list.insert(i, average_elem(sound_list[i], sound_list[i - 1]))


def average_elem(elem1, elem2):
    """
    Get two lists with two elements and returns list with the average of the two lists
    :param elem1: List with two elements
    :param elem2: List with two elements
    :return: New list with the average of the two lists
    """
    return [int((elem1[0] + elem2[0]) / 2), int((elem1[1] + elem2[1]) / 2)]  # checked efficiency of range(2) loop vs explicit [0] and [1]. this way was quicker


def average_three_elem(elem1, elem2, elem3):
    """
    Get three lists, each list with two elements and returns list with the average of the three lists
    :param elem1: List with two elements
    :param elem2: List with two elements
    :param elem3: List with two elements
    :return: List with the average of the two lists
    """
    return [int((elem1[0] + elem2[0] + elem3[0]) / 3), int((elem1[1] + elem2[1] + elem3[1]) / 3)]


def low_pass(sound_list):
    sound_list_length = len(sound_list)  # list of original sound list
    prev_elem = sound_list[0]  # save first element of list as "previous" for second element, cos going to change first element in next line
    sound_list[0] = average_elem(sound_list[0], sound_list[1])  # low pass first element
    for i in range(1, sound_list_length - 1):
        curr_before_change = sound_list[i]
        sound_list[i] = average_three_elem(sound_list[i], prev_elem, sound_list[i + 1])
        prev_elem = curr_before_change
    sound_list[sound_list_length - 1] = average_elem(sound_list[sound_list_length - 1], prev_elem)


MANIPULATIONS = {
    "1": reverse_sound,  # reverse file change
    "2": negative_sound,  # counter audio
    "3": speed_up_sound,  # speed up audio
    "4": slow_down_audio,  # slow down audio
    "5": increase_volume,  # increase volume
    "6": decrease_volume,  # decrease volume
    "7": low_pass,  # low_pass_filter
    "8": None,  # continue_to_finish_menu
}


def show_manipulation_menu(audio_data):  # depends on manipulation functions and therefore must stay under manipulation functions
    manipulation_choice = input(MANIPULATION_MENU)
    if manipulation_choice not in MANIPULATIONS:
        print("invalid")
    elif callable(MANIPULATIONS[manipulation_choice]):
        MANIPULATIONS[manipulation_choice](audio_data)  # manipulates <audio_data>
        print("successfully manipulated audio data")
    return manipulation_choice


def show_finish_menu(audio_data, sample_rate):
    wav_filename = input("Enter file name of new .wav file: ")
    failure = wave_helper.save_wave(sample_rate, audio_data, wav_filename)
    print(f"save{' failed' if failure == -1 else 'd successfully'}")


if __name__ == '__main__':
    main()
