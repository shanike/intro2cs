import sys


def main():
    print("YO:", sys.argv)

    if len(sys.argv) != 5:  # ? 5 or 4?
        print("not good: arguments are not valid")
        # exit()  # end of program # todo end program

        wordlist = read_wordlist(sys.argv[1])  # if file doesn't exist, program will end
        print(f"wordlist: {wordlist}")
        matrix = read_matrix(sys.argv[2])  # if file doesn't exist, program will end
        print(f"matrix: {matrix}")


def read_wordlist(file_name: str):
    try:
        with open(file_name, 'r') as word_file:
            return [word.rstrip() for word in word_file]
    except FileNotFoundError:
        print("not good: word file does not exist")
        exit()  # end of program


def read_matrix(file_name):
    try:
        with open(file_name, 'r') as matrix_file:
            return [row.rstrip().split(",") for row in matrix_file]
    except FileNotFoundError:
        print("not good: matrix file does not exist")
        exit()  # end of program


"""
input:

python3
0 wordsearch.py
1  word_file
2   matrix_file
3    output_file
4     directions

output:

word,number
word,number
word,number
"""

if __name__ == '__main__':
    main()
