#################################################################
# FILE : todo
# WRITER : Shani Kehati, shani , 322866823
# EXERCISE : intro2cs2 ex3
# DESCRIPTION: todo
# WEB PAGES I USED: https://stackoverflow.com/questions/522563/accessing-the-index-in-for-loops
#################################################################


# todo: check
from typing import List, Any


def input_list():
    """
    gets int values from user until user inserts an empty value
    :return: a list of all the int s that got from user
    """
    num_arr = []
    sum = 0
    while True:
        num = input("")
        if not num or not len(num):
            break
        num = float(num)
        num_arr.append(num)
        sum += num
    num_arr.append(sum)
    return num_arr


def inner_product(vec1, vec2):
    """
    calculates the inner product of 2 given vectors
    and returns it
    :param vec1: list of numbers
    :param vec2: list of numbers
    :return: inner product
    """
    inner_product_val = 0
    if len(vec1) != len(vec2):
        return None
    if not len(vec1):  # length of vec1 and of vec2 are 0 (len(vec1) == len(vec2))
        return 0
    for i, num1 in enumerate(vec1):
        inner_product_val += num1 * vec2[i]  # add inner product value to sum

    return inner_product_val


INCREASING_INDEX = 0
STRICTLY_INCREASING_INDEX = 1
DECREASING_INDEX = 2
STRICTLY_DECREASING_INDEX = 3


def sequence_monotonicity(sequence):
    """
    check the monotonicity definitions of given sequence
    :param sequence: list of numbers
    :return: monotonicity definitions of @param-sequence
    """
    definitions = [True, True, True, True]
    for i, curr_n in enumerate(sequence):
        if i == 0: continue  # no prev item - nothing to compare with
        if not (sequence[i - 1] <= curr_n):  # not inc
            definitions[INCREASING_INDEX] = False
        if not (sequence[i - 1] < curr_n):  # not strictly inc
            definitions[STRICTLY_INCREASING_INDEX] = False
        if not (sequence[i - 1] >= curr_n):  # not dec
            definitions[DECREASING_INDEX] = False
        if not (sequence[i - 1] > curr_n):  # not strictly dec
            definitions[STRICTLY_DECREASING_INDEX] = False
    return definitions


# todo
def monotonicity_inverse(def_bool):
    pass


def primes_for_asafi(n):
    """
    find first <n> prime numbers
    :param n: number of prime numbers
    :return: first <n> prime numbers
    """
    primes = []
    loop_i = 2
    while len(primes) < n:  # find next prime number until we have <n> primes
        if is_prime(loop_i):
            primes.append(loop_i)
        loop_i += 1
    return primes


def is_prime(n):
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:  # divides --> not prime
            return False
    return True


def sum_of_vectors(vec_lst):
    """
    :param vec_lst: list of vectors. e.g: [ [ 1, 1 ], [ 1, 0 ], [ 0, 100 ] ]
    :return: list of sum of all vectors
    """
    vecs_sum_list = []
    i = 0  # location to sum
    while i < len(vec_lst[0]):
        j = 0  # location of vec
        vec_sum = 0
        while j < len(vec_lst):
            vec_sum += vec_lst[j][i]
            j += 1
        vecs_sum_list.append(vec_sum)
        i += 1
    return vecs_sum_list


def num_of_orthogonal(n):
    pass
