#################################################################
# FILE : ex3.py
# WRITER : Shani Kehati, shani , 322866823
# EXERCISE : intro2cs2 ex3
# DESCRIPTION: a variety of sections
# WEB PAGES I USED: https://stackoverflow.com/questions/522563/accessing-the-index-in-for-loops
# CONSULTED WITH Ayala Cabodov about section number 4
#################################################################

def input_list():
    """
    gets int values from user until user inserts an empty value
    :return: a list of all the int s that got from user + the sum of all int s as the last item in the array
    """
    num_arr = []
    sum = 0
    while True:
        num = input("")
        if not num or not len(num):
            break
        num = float(num)
        num_arr.append(num)
        sum += num
    num_arr.append(sum)
    return num_arr


def inner_product(vec1, vec2):
    """
    calculates the inner product of 2 given vectors
    and returns it
    :param vec1: list of numbers
    :param vec2: list of numbers
    :return: inner product
    """
    inner_product_val = 0
    if len(vec1) != len(vec2):
        return None
    if not len(vec1):  # length of vec1 and of vec2 are 0 (len(vec1) == len(vec2))
        return 0
    for i, num1 in enumerate(vec1):
        inner_product_val += num1 * vec2[i]  # add inner product value to sum

    return inner_product_val


INCREASING_INDEX = 0
STRICTLY_INCREASING_INDEX = 1
DECREASING_INDEX = 2
STRICTLY_DECREASING_INDEX = 3


def sequence_monotonicity(sequence):
    """
    check the monotonicity definitions of given sequence
    :param sequence: list of numbers
    :return: monotonicity definitions of @param-sequence
    """
    definitions = [True, True, True, True]
    for i, curr_n in enumerate(sequence):
        if i == 0: continue  # no prev item - nothing to compare with
        if not (sequence[i - 1] <= curr_n):  # not inc
            definitions[INCREASING_INDEX] = False
        if not (sequence[i - 1] < curr_n):  # not strictly inc
            definitions[STRICTLY_INCREASING_INDEX] = False
        if not (sequence[i - 1] >= curr_n):  # not dec
            definitions[DECREASING_INDEX] = False
        if not (sequence[i - 1] > curr_n):  # not strictly dec
            definitions[STRICTLY_DECREASING_INDEX] = False
    return definitions


def monotonicity_inverse(def_bool):
    """
    according to given def_bool list, will return an example of a monotonicity list
    :param def_bool: list of 4 booleans
    :return: list of numbers that matches given definitions
    * according to the math behind the monotonicity lists, the only possible def_bool s are:
    1 1 0 0
    1 0 0 0
    0 0 1 0
    0 0 1 1
    0 0 0 0
    0 1 0 1
    where 1 is True and 0 is False
    """
    possible_monotonicities = [
        {"def": [True, True, False, False], "example": [1, 2, 3, 4, 5, 6, 7, 8]},
        {"def": [True, False, False, False], "example": [1, 2, 2, 3]},
        {"def": [False, False, True, False], "example": [5, 4, 3, 2, 2]},
        {"def": [False, False, True, True], "example": [7.5, 4, 3.141, 0.111]},
        {"def": [False, False, False, False], "example": [1, 0, -1, 1]},
        {"def": [True, False, True, False], "example": [1, 1, 1, 1]},
    ]
    for pos in possible_monotonicities:
        if pos["def"] == def_bool:
            return pos["example"]


def primes_for_asafi(n):
    """
    find first <n> prime numbers
    :param n: number of prime numbers
    :return: first <n> prime numbers
    """
    primes = []
    loop_i = 2
    while len(primes) < n:  # find next prime number until we have <n> primes
        if is_prime(loop_i):
            primes.append(loop_i)
        loop_i += 1
    return primes


def is_prime(n):
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:  # divides --> not prime
            return False
    return True


def sum_of_vectors(vec_lst):
    """
    :param vec_lst: list of vectors. e.g: [ [ 1, 1 ], [ 1, 0 ], [ 0, 100 ] ]
    :return: list of sum of all vectors
    """
    if not vec_lst:
        return None
    vecs_sum_list = []
    i = 0  # location to sum
    while i < len(vec_lst[0]):
        j = 0  # location of vec
        vec_sum = 0
        while j < len(vec_lst):
            vec_sum += vec_lst[j][i]
            j += 1
        vecs_sum_list.append(vec_sum)
        i += 1
    return vecs_sum_list


def num_of_orthogonal(vectors):
    """
    :param vectors: list ot vectors (List[List[int]])
    :return: number of orthogonal pairs
    """
    orthogonal_cnt = 0
    for vec1_i in range(len(vectors) - 1):
        # ^ no need to compare last position with anyone, cos until we get to him, everyone already checked themselves with him
        for vec2_i in range(vec1_i + 1, len(vectors)):  # match myself with me+1 till end of list
            if inner_product(vectors[vec1_i], vectors[vec2_i]) == 0:
                orthogonal_cnt += 1
    return orthogonal_cnt
