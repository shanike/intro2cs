import hangman_helper
from collections import Counter

UNDER_SCORE = "_"


def main():
	"""
	play hangman
	:return: no return (None)
	"""
	words = hangman_helper.load_words()
	score = run_single_game(words, hangman_helper.POINTS_INITIAL)
	game_cnt = 1
	# finished first game
	# if user finished game with a positive number of points:
	while score > 0:  # while user has a positive number of points
		lets_play_again = hangman_helper.play_again(f"You played {game_cnt} game(s). Your current score is {score} points. Would you like to play another game?")
		if not lets_play_again:
			return  # end program
		score = run_single_game(words, score)
		game_cnt += 1
	# user finished with 0 points:
	new_round = hangman_helper.play_again(f"You survived {game_cnt} game(s). Would you like to start a new round?")
	if new_round:
		main()


# end program


def run_single_game(words_list, score):
	"""
	runs a game until the user has 0 points or the user successfully found the word and won
	:return: final score of game
	"""
	msg = ""
	wrong_guesses_list = []
	random_word = hangman_helper.get_random_word(words_list)
	pattern = UNDER_SCORE * len(random_word)  # un under score character for each char in random_word

	while not is_game_over(random_word, pattern, score):  # single game:
		hangman_helper.display_state(pattern, wrong_guesses_list, score, msg)  # if msg else None
		msg = ""  # reset msg

		action_type, guess = hangman_helper.get_input()

		if action_type == hangman_helper.LETTER:
			is_valid, msg = validate_letter_guess(guess, wrong_guesses_list, pattern)  # either got True, or got False with error message
			if not is_valid:
				continue
			score -= 1
			if guess in random_word:  # correct letter guess
				(pattern, letter_occurrences) = update_word_pattern(random_word, pattern, guess, 'yes')
				score += (letter_occurrences * (
						letter_occurrences + 1) // 2)  # if letter_occurrences is 0 (not supposed to), will add 0 points...
			else:  # wrong letter guess, not in random_word
				wrong_guesses_list.append(guess)
			continue
		elif action_type == hangman_helper.WORD:
			score -= 1
			if guess == random_word:
				under_scores_guessed = get_number_of_under_scores(pattern)
				score += (under_scores_guessed * (under_scores_guessed + 1) // 2)
				pattern = guess  # was not explicitly written in instructions
				continue
		elif action_type == hangman_helper.HINT:
			# msg = "a hint is not supported in this version, please update as soon as possible we're waiting just for you, man.."
			score -= 1
			hints_lst = filter_words_list(words_list, pattern, wrong_guesses_list)
			hints_length = len(hints_lst)
			if hints_length > hangman_helper.HINT_LENGTH:
				hints_lst = [hints_lst[i * hints_length // hangman_helper.HINT_LENGTH] for i in
					range(0, hangman_helper.HINT_LENGTH)]
			hangman_helper.show_suggestions(hints_lst)
	handle_game_over(pattern, random_word, wrong_guesses_list, score)
	return score


def is_game_over(random_word, pattern, score):
	"""
	checks and returns whether game is over or not
	:return: Boolean (True / False)
	"""
	return not score or random_word == pattern


def update_word_pattern(word, pattern, letter, return_tuple=False):
	"""
	returns the updated guessing pattern of a hangman random word according to current pattern and user's letter-guess
	:param word: string - the random word
	:param pattern: string, same length as word
	:param letter: string, letter guessed by user
	:return: updated word pattern for game according to the letter the user guessed
	"""
	letter_occurrences = 0
	for i, word_letter in enumerate(word):  # going over the word (e.g: "apple")
		if word_letter == letter:  # if letter in word matches the letter, update the "_" in the pattern to the letter (e.g: "p")
			pattern = pattern[:i] + letter + pattern[i + 1:]
			letter_occurrences += 1
	return (pattern, letter_occurrences) if return_tuple == 'yes' else pattern


def validate_letter_guess(guess: str, wrong_guesses_list: [str], pattern: str):
	"""
	validates that the input we got from user is a valid letter-guess,
	in addition to checking the letter itself, the function checks that the letter was not guessed before
	(checking the current pattern (== correct guessed letters) and the wrong_guesses_list (== wrong guessed letters)
	:return: a Tuple: first value is a boolean (indicating the validity of the user's input) and the second is a relevant error message
	"""
	if len(guess) > 1 or not guess.islower() or not guess.isalpha():  # not valid letter: msg and next iteration
		return False, "guessed an invalid letter"
	if guess in wrong_guesses_list or guess in pattern:  # not valid cos already used (wrong): msg and next iteration
		return False, "you already guessed this letter"
	return True, ""


def get_number_of_under_scores(pattern):
	"""
	returns number of under_score characters in given string <patter>
	:param pattern: string
	:return: number of under scores in <pattern>
	"""
	cnt = 0
	for letter in pattern:
		if letter == UNDER_SCORE:
			cnt += 1
	return cnt


# def has_under_scores(pattern):  # instead, could just check if pattern == random_word
#     for letter in pattern:
#         if letter == UNDER_SCORE:
#             return True
#     return False
def filter_words_list(words, pattern, wrong_guess_lst):
	"""

	:param words: list of words
	:param pattern:
	:param wrong_guess_lst:
	:return: new list containing only words from <words>lst that fit the <pattern> and the <wrong_guess_lst>
	"""
	filtered_words = []
	for word in words:
		bad_word = False  # so inner for loop can "break" also outer loop
		if len(word) != len(pattern):  # <word> is not the same length as <pattern> -- not good for us
			continue
		for i in range(len(pattern)):  # loop over <pattern>
			if (pattern[i] != UNDER_SCORE and pattern[i] != word[i]) or word[i] in wrong_guess_lst:
				# if current char of pattern (==pattern[i]) is _not_ an under score (meaning it's a letter),
				# but - the letter in <word> at the same index is not the same -- word is no good for us
				# length of pattern is the same as length of word. so for every word[i] we also need to check that it's not in the wrong_guess_lst
				bad_word = True
				break
		if not bad_word:
			filtered_words.append(word)
	return filtered_words


def handle_game_over(pattern, random_word, wrong_guess_lst, score):
	"""
	checks if user won or lost the game and calls display_state (from hangman_helper) with a relevant msg
	:return: nothing
	"""
	msg = "YOU WON!" if random_word == pattern else f"GAME OVER, you lost the game... the word was: {random_word}"
	hangman_helper.display_state(pattern, wrong_guess_lst, score, msg)


if __name__ == "__main__":
	main()
